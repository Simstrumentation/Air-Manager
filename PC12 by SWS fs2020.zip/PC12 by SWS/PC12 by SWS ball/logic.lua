
circle_id = canvas_add(0, 0, 400, 200, function()
  -- Create full circle with center 100,100 and radius 100 px
  _rect(0, 0, 400, 100)
  _fill("black")
end)
img_add_fullscreen("BubbleBack.png")
img_ball      = img_add("turnslipball.png", 0,0,40,40)
img_bg_bubble = img_add_fullscreen("TurnSlipBubble.png")

---------------------------------------------
--   Functions                             --
---------------------------------------------
function new_ball_deflection(slip)
    slip = var_cap(slip, -8.1, 8.1)
    slip_rad = math.rad(slip * 1.6)
    x = (0 * math.cos(slip_rad)) - (482 * math.sin(slip_rad))
    y = (0 * math.sin(slip_rad)) + (482 * math.cos(slip_rad))
    move(img_ball, x + 180,y - 460,nil,nil)
end

function new_ball_deflection_fsx(slip)
    slip = slip * -5.5
    new_ball_deflection(slip)
end

function new_ball_deflection_fs2020(slip)
    slip = slip * -10
    new_ball_deflection(slip)
end

---------------------------------------------
--   Simulator Subscriptions               --
---------------------------------------------
xpl_dataref_subscribe("sim/cockpit2/gauges/indicators/slip_deg", "FLOAT", new_ball_deflection)

fsx_variable_subscribe("TURN COORDINATOR BALL", "Position", new_ball_deflection_fsx)

fs2020_variable_subscribe("TURN COORDINATOR BALL", "Position", new_ball_deflection_fs2020)
