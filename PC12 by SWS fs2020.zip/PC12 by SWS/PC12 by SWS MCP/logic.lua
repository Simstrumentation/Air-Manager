img_add_fullscreen("MCP.png")

txt_HDG = txt_add("HDG", "font:Roboto-Black.ttf; size:15px; color: #50C878; halign: right;", 58, 25, 120, 80)
txt_NAV = txt_add("NAV", "font:Roboto-Black.ttf; size:15px; color: #50C878; halign: right;", 115, 25, 120, 80)
txt_NAV_arm = txt_add("ARM", "font:Roboto-Black.ttf; size:15px; color: #FFFFFF; halign: right;", 145, 25, 120, 80)
txt_APR = txt_add("APR", "font:Roboto-Black.ttf; size:15px; color: #50C878; halign: right;", 180, 25, 120, 80)
txt_APR_arm = txt_add("ARM", "font:Roboto-Black.ttf; size:15px; color: #FFFFFF; halign: right;", 210, 25, 120, 80)
txt_YD = txt_add("YD", "font:Roboto-Black.ttf; size:15px; color: #50C878; halign: right;", 322, 25, 120, 80)
txt_AP = txt_add("AP", "font:Roboto-Black.ttf; size:15px; color: #50C878; halign: right;", 389, 25, 120, 80)
txt_ALT = txt_add("ALT", "font:Roboto-Black.ttf; size:15px; color: #50C878; halign: right;", 60, 145, 120, 80)
txt_IAS = txt_add("IAS", "font:Roboto-Black.ttf; size:15px; color: #50C878; halign: right;", 125, 145, 120, 80)
txt_FD = txt_add("FD", "font:Roboto-Black.ttf; size:15px; color: #50C878; halign: right;", 188, 145, 120, 80)
txt_HB = txt_add("HB", "font:Roboto-Black.ttf; size:15px; color: #50C878; halign: right;", 322, 145, 120, 80)
txt_Trim = txt_add("Trim", "font:Roboto-Black.ttf; size:15px; color: #FF0000; halign: right;", 393, 145, 120, 80)
visible(txt_Trim, false)

--vars
b_hdg = false
b_nav = false
b_nav_arm = false
b_apr = false
b_yd = false
b_ap = false
b_alt = false
b_apr_arm = false
b_ias = false
b_fd = false
b_hb = false
b_dn_pressed = false
b_up_pressed = false
b_hb_pressed = false
b_test_pressed = false
b_blink = false
count = 0
b_arm = false

--functions
function dn_button_pressed()
    --b_dn_pressed = true 
    --count = 0
    if (b_ias) then --ias mode
        fs2020_event("AP_SPD_VAR_INC")
    else
        fs2020_event("AP_PITCH_REF_INC_DN")
    end
end

function dn_button_released()
    --b_dn_pressed = false
end

function up_button_pressed()
    --b_up_pressed = true
    if (b_ias) then --ias mode
        fs2020_event("AP_SPD_VAR_DEC")
    else
        fs2020_event("AP_PITCH_REF_INC_UP")
    end
end

function up_button_released()
    --b_up_pressed = false
end

function HDG_button_pressed()
    fs2020_event("AP_PANEL_HEADING_HOLD")
    --xpl_command("sim/autopilot/heading")
end

function NAV_button_pressed()
    fs2020_event("AP_NAV1_HOLD")
    --xpl_command("sim/autopilot/NAV")
end

function APR_button_pressed()
    fs2020_event("AP_APR_HOLD")
    --xpl_command("sim/autopilot/approach")
end

function YD_button_pressed()
    fs2020_event("YAW_DAMPER_TOGGLE")
    --xpl_command("sim/systems/yaw_damper_toggle")
end

function AP_button_pressed()
    fs2020_event("AP_MASTER")
    --b_ap = not b_ap
    --if (b_ap) then
    --    xpl_command("sim/autopilot/servos_on")
    --else
    --    xpl_command("pc12/IMPORTANT/autopilot_disconnect")
    --end
end

function ALT_button_pressed()
    fs2020_event("AP_ALT_HOLD")
    --xpl_command("sim/autopilot/altitude_hold")
end

function IAS_button_pressed()

    if (not b_arm) then fs2020_event("H:AUTOPILOT_KAS297B_Push_AltitudeSelect_1") end

    fs2020_event("FLIGHT_LEVEL_CHANGE")
    --xpl_command("sim/autopilot/level_change")
end

function FD_button_pressed()
    fs2020_event("TOGGLE_FLIGHT_DIRECTOR")
    --xpl_command("sim/autopilot/fdir_toggle")
end

function SOFT_RIDE_button_pressed()

end

function HALF_BANK_button_pressed()
    b_hb_pressed = not b_hb_pressed
    
    if (b_hb_pressed) then
        fs2020_event("AP_MAX_BANK_SET", 1)
    else
        fs2020_event("AP_MAX_BANK_SET", 0)
    end
    
    --xpl_command("sim/autopilot/bank_limit_toggle")
end

function TEST_button_pressed()
    fs2020_event("B:INSTRUMENT_aptst_Push")
    b_test_pressed = true
    visible(txt_Trim, true)
end

function TEST_button_released()
    b_test_pressed = false
    visible(txt_Trim, false)
    
    visible(txt_HDG, b_hdg)
    visible(txt_NAV, b_nav)
    visible(txt_NAV_arm, b_nav_arm)
    visible(txt_APR, b_apr)
    visible(txt_APR_arm, b_apr_arm)
    visible(txt_YD, b_yd)
    visible(txt_AP, b_ap)
    visible(txt_ALT, b_alt)
    visible(txt_IAS, b_ias)
    visible(txt_FD, b_fd)
    visible(txt_HB, b_hb)
    visible(txt_Trim, false)
end

function hdg(myBool)
    visible(txt_HDG, myBool)
    b_hdg = myBool
end

function nav(myInt)
    if (myInt == 1) then
        visible(txt_NAV, false)
        b_nav = false
        visible(txt_NAV_arm, true)
        b_nav_arm =true
    elseif (myInt == 2) then
        visible(txt_NAV, true)
        b_nav = true
        visible(txt_NAV_arm, false)
        b_nav_arm = false
    else
        visible(txt_NAV, false)
        b_nav = false
        visible(txt_NAV_arm, false)
        b_nav_arm = false
    end
end

function apr(myInc)
    if (myInc == 2) then
        visible(txt_APR, true)
        b_apr = true
        visible(txt_APR_arm, false)
        b_apr_arm = false
    elseif (myInc == 1) then
        visible(txt_APR, false)
        b_apr = false
        visible(txt_APR_arm, true)
        b_apr_arm = true
    else--myInc==0
        visible(txt_APR, false)
        b_apr = false
        visible(txt_APR_arm, false)
        b_apr_arm = false
    end 
    
end

function alt(myBool)
    visible(txt_ALT, myBool)
end

function ias(myBool)
    visible(txt_IAS, myBool)
    b_ias = myBool
end

function fd(myBool)
    visible(txt_FD, myBool)
    b_fd = myBool
end

function ap(myBool)
    visible(txt_AP, myBool)
    b_ap = myBool
end

function yd(myBool)
    visible(txt_YD, myBool)
    b_yd = myBool
end

function hb(rad)
    if (rad < .4) then
        b_hb_pressed = true
    else
        b_hb_pressed = false
    end
    visible(txt_HB, b_hb_pressed)
end


function timer_callback()--loop for pitch button pressed 
    --if (b_dn_pressed) then
    --    fs2020_event("AP_PITCH_REF_INC_DN")
        --xpl_command("sim/autopilot/nose_down_pitch_mode")
    --elseif (b_up_pressed) then
    --    fs2020_event("AP_PITCH_REF_INC_UP")
        --xpl_command("sim/autopilot/nose_up_pitch_mode")   
    --end
    
    if (b_test_pressed) then
        visible(txt_HDG, true)
        visible(txt_NAV, true)
        visible(txt_NAV_arm, true)
        visible(txt_APR, true)
        visible(txt_APR_arm, true)
        visible(txt_YD, true)
        visible(txt_AP, true)
        visible(txt_ALT, true)
        visible(txt_IAS, true)
        visible(txt_FD, true)
        visible(txt_HB, true)
        
        --blink trim
        count = count + 1
        if (count < 5) then
            visible(txt_Trim, true)
        elseif (count < 10) then
            visible(txt_Trim, false)
        else
            count = 0
        end    
    end
end

function get_ARM(myFloat)
    if (myFloat == 1) then
        b_arm = true
    else
        b_arm = false
    end
end

--subscriptions
fs2020_variable_subscribe("AUTOPILOT HEADING LOCK", "Bool", hdg)
fs2020_variable_subscribe("L:SWS_AUTOPILOT_Navigation_1_Mode", "float", nav)
fs2020_variable_subscribe("L:SWS_AUTOPILOT_Approach_1_Mode", "float", apr)
fs2020_variable_subscribe("AUTOPILOT ALTITUDE LOCK", "Bool", alt)
fs2020_variable_subscribe("AUTOPILOT FLIGHT LEVEL CHANGE", "Bool", ias)
fs2020_variable_subscribe("AUTOPILOT FLIGHT DIRECTOR ACTIVE", "Bool", fd)
fs2020_variable_subscribe("AUTOPILOT MASTER", "Bool", ap)
fs2020_variable_subscribe("AUTOPILOT YAW DAMPER", "Bool", yd)
fs2020_variable_subscribe("AUTOPILOT MAX BANK", "Radians", hb)
fs2020_variable_subscribe("L:SWS_KAS297B_AltitudeArm", "float", get_ARM)

--xpl_dataref_subscribe("sim/cockpit/warnings/annunciators/autopilot_bank_limit", "int", hb)
--xpl_dataref_subscribe("sim/aircraft/view/acf_has_SC_fd", "int", fd)
--xpl_dataref_subscribe("sim/cockpit2/autopilot/speed_status", "int", ias)
--xpl_dataref_subscribe("sim/cockpit2/autopilot/altitude_hold_status", "int", alt)
--xpl_dataref_subscribe("sim/cockpit2/autopilot/autopilot_on_or_cws", "int", ap)
--xpl_dataref_subscribe("sim/cockpit/switches/yaw_damper_on", "int", yd)
--xpl_dataref_subscribe("sim/cockpit2/autopilot/approach_status", "int", apr)
--xpl_dataref_subscribe("sim/cockpit2/autopilot/nav_status", "int", nav)
--xpl_dataref_subscribe("sim/cockpit2/autopilot/heading_mode", "int", hdg)

timer_start(0, 100, timer_callback)--loop timer for pitch button pressed down

--add buttons
button_add(nil, "DN.png", 70, 47, 50, 50, dn_button_pressed, dn_button_released)
button_add(nil, "UP.png", 70, 180, 50, 50, up_button_pressed)
button_add(nil, "HDG.png", 135, 55, 60, 57, HDG_button_pressed)
button_add(nil, "NAV.png", 203, 55, 60, 57, NAV_button_pressed)
button_add(nil, "APR.png", 270, 55, 60, 57, APR_button_pressed)
button_add(nil, "YD.png", 403, 55, 60, 57, YD_button_pressed)
button_add(nil, "AP.png", 472, 55, 60, 57, AP_button_pressed)

button_add(nil, "ALT.png", 135, 170, 60, 57, ALT_button_pressed)
button_add(nil, "IAS.png", 203, 170, 60, 57, IAS_button_pressed)
button_add(nil, "FD.png", 270, 170, 60, 57, FD_button_pressed)
button_add(nil, "SOFT_RIDE.png", 337, 170, 60, 57, SOFT_RIDE_button_pressed)
button_add(nil, "HALF_BANK.png", 403, 170, 60, 57, HALF_BANK_button_pressed)
button_add(nil, "TEST.png", 472, 170, 60, 57, TEST_button_pressed, TEST_button_released)
