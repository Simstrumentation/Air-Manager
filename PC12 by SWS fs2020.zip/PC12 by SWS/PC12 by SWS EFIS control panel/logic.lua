prop_fs2020_172 = user_prop_add_boolean("FS2020", false, "")

img_add_fullscreen("pc12_EHSI_controls.png")

local brg1 = 0
local brg2 = 0
local b_Arc = false
local map_rng = 0
local DH = 0
local b_DH = false
local f_EHSI_brt = 1.0
local f_EADI_brt = 1.0
local b_HSIonGPS = true
local Nav1orNav2 = 1
local EADI_brightness = 0
local EHSI_brightness = 0
local heading = 0
local course = 0
local CDIdef = 0
local b_pushDirect = false
local timer_count = 0

function sleep(n)
    os.execute("sleep " .. tonumber(n))
end

function nav_button_pressed()
 
    if (b_HSIonGPS and Nav1orNav2 == 1)then--switch to NAV1
        xpl_command("sim/autopilot/hsi_select_nav_1")
    elseif (b_HSIonGPS and Nav1orNav2 == 2)then--switch to NAV2
        xpl_command("sim/autopilot/hsi_select_nav_2")
    else--switch to GPS
        xpl_command("sim/autopilot/hsi_select_gps")
    end
    
    fs2020_event("H:SWS_EFIS50_Push_Nav_1", 1)
    
end

function course_direct()
    xpl_command("sim/radios/obs_HSI_direct")
    
    --fs
    if fs2020_connected() then
       b_pushDirect = true
    end
    --fs2020_event("VOR1_SET", 100)--set cdi
    
end

--dial functions
function turn_heading_knob(direction)
  -- Direction will have the value
  --  1: When the dial is being turned clockwise
  -- -1: When the dial is being turned anti-clockwise
  --print("dial has been turned into direction " .. direction)
  if (direction < 0)then
      xpl_command("sim/autopilot/heading_down")
      fs2020_event("HEADING_BUG_DEC")
  else
      xpl_command("sim/autopilot/heading_up")
      fs2020_event("HEADING_BUG_INC") 
  end
  
end

function turn_course_knob(direction)
  -- Direction will have the value
  --  1: When the dial is being turned clockwise
  -- -1: When the dial is being turned anti-clockwise
  --print("dial has been turned into direction " .. direction)
  if (direction < 0)then
      xpl_command("sim/radios/obs1_down")
  else
      xpl_command("sim/radios/obs1_up")
  end
  
  fs2020_event("B:AUTOPILOT_Course_Dyn_1", direction)--0 dec / 1 inc
  b_pushDirect = false
  
end

function turn_DH_knob(direction)
  -- Direction will have the value
  --  1: When the dial is being turned clockwise
  -- -1: When the dial is being turned anti-clockwise
  --print("dial has been turned into direction " .. direction)
  if (direction < 0)then
      xpl_command("sim/instruments/dh_ref_down")
      
      --fs
      DH = DH - 1
      if (DH < 0) then DH = 0 end
       
  else
      xpl_command("sim/instruments/dh_ref_up")
      
      --fs
      DH = DH + 1
      if (DH > 500) then DH = 500 end
  end
  
  fs2020_variable_write("L:SWS_EFIS50_Decision_Height_1", "Number", DH)--sets DH
end

function turn_EHSIbrightness_knob(direction)
  -- Direction will have the value
  --  1: When the dial is being turned clockwise
  -- -1: When the dial is being turned anti-clockwise
  --print("dial has been turned into direction " .. direction)
  if (direction < 0)then
      --xpl
      f_EHSI_brt = f_EHSI_brt - .1
      if (f_EHSI_brt < 0.1) then f_EHSI_brt = 0.1 end
      --fs
      EHSI_brightness = EHSI_brightness - 1
      if (EHSI_brightness < 0)then EHSI_brightness = 0 end
  else
      
      f_EHSI_brt = f_EHSI_brt + .1
      if (f_EHSI_brt > 1.0) then f_EHSI_brt = 1.0 end
      --fs
      EHSI_brightness = EHSI_brightness + 1
      if (EHSI_brightness > 100)then EHSI_beightness = 100 end
  end
  xpl_dataref_write("sim/cockpit2/switches/instrument_brightness_ratio", "float[32]", {f_EHSI_brt}, 6)
  fs2020_event("B:LIGHTING_POTENTIOMETER_1",  EHSI_brightness)
end

function turn_EADIbrightness_knob(direction)
  -- Direction will have the value
  --  1: When the dial is being turned clockwise
  -- -1: When the dial is being turned anti-clockwise
  --print("dial has been turned into direction " .. direction)
  if (direction < 0)then
      --xpl
      f_EADI_brt = f_EADI_brt - .1
      if (f_EADI_brt < 0.1) then f_EADI_brt = 0.1 end
      --fs
      EADI_brightness = EADI_brightness - 1
      if (EADI_brightness < 0)then EADI_brightness = 0 end
  else
      --xpl
      f_EADI_brt = f_EADI_brt + .1
      if (f_EADI_brt > 1.0) then f_EADI_brt = 1.0 end
      --fs
      EADI_brightness = EADI_brightness + 1
      if (EADI_brightness > 100)then EADI_brightness = 100 end
  end
  xpl_dataref_write("sim/cockpit2/switches/instrument_brightness_ratio", "float[32]", {f_EADI_brt}, 2)
  fs2020_event("B:LIGHTING_POTENTIOMETER_1",  EADI_brightness)
end

function hsi_button_pressed()
    if (b_Arc)then
        xpl_dataref_write("thranda/autopilot/MapArcHSI", "Int", 2)
        
    end
    fs2020_event("H:SWS_EFIS50_Push_HSI_1", 1)
end

function arc_button_pressed()
    if (not b_Arc)then
        xpl_dataref_write("thranda/autopilot/MapArcHSI", "Int", 1)
    end
    fs2020_event("H:SWS_EFIS50_Push_Arc_1", 1)
end

function rngup_button_pressed()
    map_rng = map_rng + 1
    if (map_rng > 6) then map_rng = 6 end
    xpl_dataref_write("sim/cockpit2/EFIS/map_range", "int", map_rng)
    fs2020_event("H:SWS_EFIS50_Push_RangeInc_1", 1)
end

function needle1_button_pressed()
    brg1 = brg1 + 1
    if (brg1 > 4)then brg1 = 0 end
    xpl_dataref_write("thranda/autopilot/VOR12_ADF1", "float", brg1)
    fs2020_event("H:SWS_EFIS50_Push_SelectPointer1_1", 1)
end

function needle2_button_pressed()
    brg2 = brg2 + 1
    if (brg2 > 4)then brg2 = 0 end
    xpl_dataref_write("thranda/autopilot/VOR12_ADF2", "float", brg2)
    fs2020_event("H:SWS_EFIS50_Push_SelectPointer2_1", 1)
end

function button12_pressed()
    
    xpl_command("sim/autopilot/hsi_toggle_nav")
    fs2020_event("H:SWS_EFIS50_Push_SelectReference_1", 1)
    
end

function rngdn_button_pressed()
print(map_rng)
    map_rng = map_rng - 1
    if (map_rng < 0) then map_rng = 0 end
    xpl_dataref_write("sim/cockpit2/EFIS/map_range", "int", map_rng)
    fs2020_event("H:SWS_EFIS50_Push_RangeDec_1", 1)
end

function DH_pressed()
print(DH)
    b_DH = not b_DH
    if (b_DH) then
        xpl_dataref_write("sim/cockpit/misc/radio_altimeter_minimum", "float", DH)
    else
        xpl_dataref_write("sim/cockpit/misc/radio_altimeter_minimum", "float", 0)
    end
    fs2020_variable_write("L:SWS_EFIS50_Knob_DecisionHeight_2_Pull", "Bool", true)
end

function setDH(f_min)
    local mins = math.floor(f_min)
    if (mins > 0) then
        b_DH = true
        DH = mins
    else
        b_DH = false
    end
end

function setHSIonGPS(source)
    if (source == 2)then--GPS
        b_HSIonGPS = true
    elseif (source == 1)then--NAV2
        b_HSIonGPS = false
        Nav1orNav2 = 2
    else--NAV1
       b_HSIonGPS = false 
       Nav1orNav2 = 1
    end
end

function HDG_sync_pressed()
    xpl_command("sim/autopilot/heading_sync")
    fs2020_event("HEADING_BUG_SET", heading)
end

function setArc(Arc)
    if (Arc == 1)then--ARC mode
        b_Arc = true
    else--HSI mode
        b_Arc = fale
    end
end

function setNeedle1(set)
    brg1 = set
end

function setNeedle2(set)
    brg2 = set
end

function setEADIbrightness(percent)
    EADI_brightness = percent
end

function setEHSIbrightness(percent)
    EHSI_brightness = percent
end

function getHeading(deg)
    heading = deg
end

--function getBearing(deg)
--    print(deg)
--end

function getCDI(def)
    CDIdef = def
end

--timer to update course direct push button
function timer_callback()
    if (b_pushDirect) then
        timer_count = timer_count + 1
        
        if (math.abs(CDIdef) > 2) then 
                fs2020_event("B:AUTOPILOT_Course_Dyn_1", 1)--0 dec / 1 inc
                --fs2020_event("VOR1_SET", x)--set cdi
        else
           timer_count = 0
           b_pushDirect = false
        end
        
        --turn off timer count
        if (timer_count >= 360) then
            timer_count = 0
            b_pushDirect = false
        end
    end
end

--add variable subscriptions
xpl_dataref_subscribe("sim/cockpit/misc/radio_altimeter_minimum", "float", setDH)
xpl_dataref_subscribe("sim/cockpit/switches/HSI_selector", "Int", setHSIonGPS)
xpl_dataref_subscribe("thranda/autopilot/MapArcHSI", "Int", setArc)
xpl_dataref_subscribe("thranda/autopilot/VOR12_ADF1", "Int", setNeedle1)
xpl_dataref_subscribe("thranda/autopilot/VOR12_ADF2", "Int", setNeedle2)
--fs
fs2020_variable_subscribe("L:SWS_EFIS50_Decision_Height_1", "Number", setDH)--sets DH
fs2020_variable_subscribe("LIGHT POTENTIOMETER:1", "Percent", setEADIbrightness)
fs2020_variable_subscribe("LIGHT POTENTIOMETER:2", "Percent", setEHSIbrightness)
fs2020_variable_subscribe("L:SWS_INSTRUMENT_GyroCompassHeading_1", "float", getHeading)
--fs2020_variable_subscribe("HSI BEARING", "Degrees", getBearing)
fs2020_variable_subscribe("HSI CDI NEEDLE", "Number", getCDI)

--add dials
dial_add("heading_knob.png",464,175,70,70,5, turn_heading_knob)
dial_add("course_knob.png",55,172,75,75,5, turn_course_knob)
dial_add("knob.png",60,29,60,60,5, turn_DH_knob)
dial_add("knob.png",460,30,60,60,5, turn_EHSIbrightness_knob)
dial_add("brightness_knob.png",470,40,40,40,5, turn_EADIbrightness_knob)


--add buttons
button_add(nil, "HSI_pressed.png", 165, 78, 58, 53, hsi_button_pressed)
button_add(nil, "ARC_pressed.png", 235, 78, 58, 53, arc_button_pressed)
button_add(nil, "NAV_pressed.png", 305, 78, 58, 53, nav_button_pressed)
button_add(nil, "RNG_UP_pressed.png", 370, 78, 58, 53, rngup_button_pressed)
button_add(nil, "NEEDLE1_pressed.png", 165, 165, 58, 53, needle1_button_pressed)
button_add(nil, "NEEDLE2_pressed.png", 235, 165, 58, 53, needle2_button_pressed)
button_add(nil, "1-2_pressed.png", 305, 165, 58, 53, button12_pressed)
button_add(nil, "RNG_DN_pressed.png", 370, 165, 58, 53, rngdn_button_pressed)
button_add(nil, nil, 480, 190, 40, 40, HDG_sync_pressed)
button_add(nil, nil, 72, 190, 40, 40, course_direct)
button_add(nil, nil, 72, 190, 40, 40, course_direct)
button_add(nil, nil, 71, 39, 40, 40, DH_pressed)

--timer callback to update course direct
timer_start(0, 300, timer_callback)--loop timer