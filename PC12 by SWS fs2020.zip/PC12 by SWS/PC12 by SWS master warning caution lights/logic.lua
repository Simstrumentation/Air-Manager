b_mc = false
b_mw = false


function MC_pressed()
    fs2020_event("K:MASTER_CAUTION_ACKNOWLEDGE")
    --fs2020_event("MASTER_AUSTION_TOGGLE")
    MC_callback(false)
end

function MW_pressed()
    fs2020_event("K:MASTER_WARNING_ACKNOWLEDGE")
    --fs2020_event("MASTER_WARNING_TOGGLE")
    MW_callback(false)
end

function MC_callback(myBool)
    visible(cautionOn, myBool)
    b_mc = myBool
end

function MW_callback(myBool)
    visible(warningOn, myBool)
    b_mw = myBool
end

function lamp_test(myBool)
    if (myBool) then
        visible(cautionOn, myBool)
        visible(warningOn, myBool)
    else
        visible(cautionOn, b_mc)
        visible(warningOn, b_mw)
    end
    
end

--draw background
canvas_id = canvas_add(0, 0, 256, 50, function()
  -- Create a rectangle
  _rect(0, 0, 256, 50)

  _fill("black")
end)

visible(canvas_id, true)

--add images
cautionOff = img_add("Master_Off.png", 0,0, 85, 50)
cautionOn = img_add("Master_Caution_On.png", 0,0, 85, 50)
--visible(cautionOn, false)
warningOff = img_add("Master_Off.png", 115,0, 85, 50)
warningOn = img_add("Master_Warning_On.png", 115, 0, 85, 50)
--visible(warningOn, false)

--add buttons
MC_button = button_add(nil, nil, 0, 0, 85, 50, MC_pressed)
MW_button = button_add(nil, nil, 115, 0, 85, 50, MW_pressed)

--subscribe to vars
fs2020_variable_subscribe("MASTER CAUTION ACTIVE", "Bool", MC_callback)
fs2020_variable_subscribe("MASTER WARNING ACTIVE", "Bool", MW_callback)
fs2020_variable_subscribe("L:SAFETY_Push_TestLamp", "Bool", lamp_test)