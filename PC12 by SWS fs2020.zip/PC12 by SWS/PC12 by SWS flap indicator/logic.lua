function rotate_needle(deg)

    rot = math.rad(deg)
    print(rot)
    rot = (rot * 13)
    rot = rot * rot
    print(rot)
    if (rot == 0) then
        rot = -5
    elseif (rot > 80) then
        rot = 90
    end
    rotate(needle, rot)--25, 65, 90
end

function overspeed(myBool)
    visible(as, myBool)
end

--load images
img_add("Flaps.png", 0, 0, 110, 110)
needle = img_add("Flap_needle.png", 20, 15, 70, 65)
as = img_add("Airspeed.png", 40,20, 37,21)

--variable subscribes
fs2020_variable_subscribe("TRAILING EDGE FLAPS LEFT ANGLE", "Degrees", rotate_needle)--flap needle
fs2020_variable_subscribe("L:SWS_WARNING_FLAPS_OVERSPEED", "Bool", overspeed)--A/S light