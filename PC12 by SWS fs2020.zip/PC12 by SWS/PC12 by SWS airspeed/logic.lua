Vne = 236--248
Vmo = 0.48

-- Add images --
img_add_fullscreen("Anemometer.png")
img_red_needle = img_add_fullscreen("RedNeedleAnemo.png")
img_white_needle = img_add_fullscreen("WhiteNeedleAnemo.png")
img_add_fullscreen("CapNeedleAnemo.png")
rotate(img_white_needle, 0)

-- Functions --
function PT_airspeed(airspeed, Temp_sea, Temp, Alt)
    
    airspeed = var_cap(airspeed, 0, 300)
    
    if airspeed <= 40 then
        rotate (img_white_needle, airspeed * 10 / 40)
    elseif airspeed > 40 then
        rotate(img_white_needle, airspeed * 285 / 260 - 40)--320 / 260 - 40)
    end
    
    --red pole
    CS0 = 38.967854 * (Temp_sea + 273.15)^0.5 -- speed of sound at sea level
    CS = 38.967854 * (Temp + 273.15)^0.5 -- speed of sound at current level

    x = (1 - 6.8755856 * 10^-6 * Alt)^5.2558797
    a = (1 + Vmo^(2/5))^3.5 - 1
    limitIas2 = CS0 * ((((1 + x * a)^(2/7)) - 1) / 5)^0.435  -- red pole limit IAS computed with compressibility
    --limitIas2 = CS0 * ((((1 + x * a)^(2/7)) - 1) / 5)^0.5  -- red pole limit IAS computed with compressibility


print(limitIas2 .. "<" .. Vne)

    if limitIas2 < Vne then
        --rotate(img_red_needle, limitIas2 * 320 / 260 - 38)
        rotate(img_red_needle, limitIas2 * 320 / 260 - 70)
    elseif limitIas2 >= Vne then
        --rotate(img_red_needle, Vne * 320 / 260 - 38)
        rotate(img_red_needle, Vne * 320 / 260 - 70)
    end
    
end


-- Data subscribe --
xpl_dataref_subscribe("sim/cockpit2/gauges/indicators/airspeed_kts_pilot", "FLOAT", 
                      "sim/weather/temperature_sealevel_c", "FLOAT", 
                      "sim/cockpit2/temperature/outside_air_temp_degc", "FLOAT",
                      "sim/cockpit2/gauges/indicators/altitude_ft_pilot", "FLOAT", PT_airspeed)
fsx_variable_subscribe("AIRSPEED INDICATED", "Knots",
                       "AMBIENT TEMPERATURE", "Celsius",
                       "TOTAL AIR TEMPERATURE", "Celsius",
                       "PRESSURE ALTITUDE", "Feet", PT_airspeed)
fs2020_variable_subscribe("AIRSPEED INDICATED", "Knots",
                          "AMBIENT TEMPERATURE", "Celsius",
                          "TOTAL AIR TEMPERATURE", "Celsius",
                          "PRESSURE ALTITUDE", "Feet", PT_airspeed)                       