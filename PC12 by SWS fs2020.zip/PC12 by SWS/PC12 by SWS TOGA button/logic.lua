b_fd = false
b_GA = false

function getFD(myBool)
    b_fd = myBool
end

function TOGA_callback()

    fs2020_event("TOGGLE_FLIGHT_DIRECTOR")
    b_GA = true

end

function timer_callback()
print(b_GA)
    if (b_GA) then
        if (b_fd) then--TOGA and FD on
            b_GA = false
            fs2020_event("AP_PITCH_REF_SET", -23000)
            fs2020_event("AUTO_THROTTLE_TO_GA")
        else--TOGA and FD off
            fs2020_event("TOGGLE_FLIGHT_DIRECTOR")
        end
    end
    
end

fs2020_variable_subscribe("AUTOPILOT FLIGHT DIRECTOR ACTIVE", "Bool", getFD)
timer_start(0, 1000, timer_callback)--loop timer

button_add("TOGA.png", nil, 0, 0, 150, 50, TOGA_callback)