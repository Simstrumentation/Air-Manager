
pinUP = "D2"
pinDN = "D3"

-- Buttons, switches and dials functions --
function gear_switch(state, direction)

    xpl_command( fif(state == 0, "sim/flight_controls/landing_gear_down", "sim/flight_controls/landing_gear_up") )
    fsx_event( fif(state == 0, "GEAR_DOWN", "GEAR_UP") )
    fs2020_event( fif(state == 0, "GEAR_DOWN", "GEAR_UP") )

end

-- Add images in Z-order --
img_add_fullscreen("gearback.png")
img_LH = img_add("LG_green.png",0,60,60,60, "visible:false")
img_NO = img_add("LG_green.png",25,0,60,60, "visible:false")
img_RH = img_add("LG_green.png",50,60,60,60, "visible:false")

img_LH_unlock = img_add("unlock.png",0,60,60,60, "visible:false")
img_NO_unlock = img_add("unlock.png",25,0,60,60, "visible:false")
img_RH_unlock = img_add("unlock.png",50,60,60,60, "visible:false")

-- Functions --
function new_gear_deploy(deployratio, handle, bus_volts)
    
    local power = bus_volts[1] >= 5
    
    -- Check if one of the wheels is in transition, 0 is all up, 3 is all down
    gear_total = deployratio[1] + deployratio[2] + deployratio[3]
    visible(img_LH, deployratio[1] == 1 and power)
    visible(img_NO, deployratio[2] == 1 and power)
    visible(img_RH, deployratio[3] == 1 and power)
    
    switch_set_position(switch_handle, handle)
    
    if (deployratio[1] < 1 and deployratio[1] > 0) then
        visible(img_LH_unlock, true)
    else
        visible(img_LH_unlock, false)
    end
    
    if (deployratio[2] < 1 and deployratio[2] > 0) then
        visible(img_NO_unlock, true)
    else
        visible(img_NO_unlock, false)
    end
    
    if (deployratio[3] < 1 and deployratio[3] > 0) then
        visible(img_RH_unlock, true)
    else
        visible(img_RH_unlock, false)
    end

end

function new_gear_deploy_FSX(center, left, right, handle, bus_volts)

    center = center / 100
    left = left / 100
    right = right / 100
    
    if handle then
        handle = 1
    else
        handle = 0
    end
    
    new_gear_deploy({left, center, right}, handle, {bus_volts})

end

-- Buttons, switches and dials --
switch_handle = switch_add("handleup.png", "handledown.png", 107, 63, 30, 150, gear_switch)

-- Bus subscription --
xpl_dataref_subscribe("sim/aircraft/parts/acf_gear_deploy", "FLOAT[10]",
                      "sim/cockpit2/controls/gear_handle_down", "INT",
                      "sim/cockpit2/electrical/bus_volts", "FLOAT[6]", new_gear_deploy)
fsx_variable_subscribe("GEAR CENTER POSITION", "Percent", 
                       "GEAR LEFT POSITION", "Percent", 
                       "GEAR RIGHT POSITION", "Percent", 
                       "GEAR HANDLE POSITION", "Bool", 
                       "ELECTRICAL MAIN BUS VOLTAGE", "Volts", new_gear_deploy_FSX)
fs2020_variable_subscribe("GEAR CENTER POSITION", "Percent", 
                          "GEAR LEFT POSITION", "Percent", 
                          "GEAR RIGHT POSITION", "Percent", 
                          "GEAR HANDLE POSITION", "Bool", 
                          "ELECTRICAL MAIN BUS VOLTAGE", "Volts", new_gear_deploy_FSX)
                          
--add hardware

function gear_up()
  switch_set_position(switch_handle, 0)
  fs2020_event("GEAR_UP")
  xpl_command("sim/flight_controls/landing_gear_up")
end

function gear_dn()
  switch_set_position(switch_handle, 1)
  fs2020_event("GEAR_DOWN")
  xpl_command("sim/flight_controls/landing_gear_down")
end

function nocall()

end

pinUP = user_prop_add_enum("Arduino Pin UP", "D2, D3, D4, D5, D6, D7, D8, D9, D10, D11, D12", "D2", "Choose arduino pin for gear UP")
pinDN = user_prop_add_enum("Arduino Pin Down", "D2, D3, D4, D5, D6, D7, D8, D9, D10, D11, D12", "D3", "Choose arduino pin for gear Down")

if hw_connected("ARDUINO_NANO_B_D2") then
  
    -- Bind to Nano
    hw_button_add("ARDUINO_NANO_B_" .. user_prop_get(pinUP), gear_up, nocall)
    hw_button_add("ARDUINO_NANO_B_" .. user_prop_get(pinDN), gear_dn, nocall)
end                          					   					   