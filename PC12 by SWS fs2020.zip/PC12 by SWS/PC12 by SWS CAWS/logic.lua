img_add_fullscreen("CAWS.png")

--variables
b_red_blank1 = false
b_red_blank2 = false
b_red_blank3 = false
b_pass_door = false
b_car_door = false
b_cab_press = false
b_air_gnd = false
b_prop_low_p = false
b_ap_trim_red = false
b_esntl_bus = false
b_av_bus = false
b_stab_trim = false
b_oil_qty = false
b_eng_fire = false
b_gen_2_off = false
b_bus_tie = false
b_pusher = false
b_fire_detect = false
b_gen_1_off = false
b_inverter = false
b_bat_hot = false
b_flaps = false
b_chip = false
b_caws_fail = false
b_bat_off = false
b_fuel_press = false
b_hydr = false
b_ecs = false
b_aoa_deice = false
b_nesntl_bus = false
b_l_fuel_low = false
b_ap_diseng = false
b_deice_boots = false
b_inert_sep = false
b_static = false
b_r_fuel_low = false
b_battery = false
b_oil_qty_amber = false
b_wshld_heat = false
b_pitot1 = false
b_pitot2 = false
b_prop_deice = false
b_l_fuel_pump = false
b_ap_trim_green = false
b_pusher_ice_mode = false
b_deice_boots_green = false
b_pass_oxy = false
b_r_fuel_pump = false

--CAWS lights
--row 1
pass_door = img_add("pass_door.png", 40,22, 80,20)
car_door = img_add("car_door.png", 128,22, 80,20)
cab_press = img_add("cab_press.png", 216,22, 80,20)
air_gnd = img_add("air_gnd.png", 304,22, 80,20)
prop_low_p = img_add("prop_low_p.png", 392,22, 80,20)
ap_trim_red = img_add("ap_trim.png", 482,22, 80,20)
--row 2
esntl_bus = img_add("esntl_bus.png", 40,49, 80,20)
av_bus = img_add("av_bus.png", 128,49, 80,20)
stab_trim = img_add("stab_trim.png", 216,49, 80,20)
oil_qty = img_add("oil_qty.png", 304,49, 80,20)
eng_fire = img_add("eng_fire.png", 392,49, 80,20)
red_blank1 = img_add("red_blank.png", 482,49, 80,20)
--row3
red_blank2 = img_add("red_blank.png", 40,76, 80,20)
gen_2_off = img_add("gen_2_off.png", 128,76, 80,20)
bus_tie = img_add("bus_tie.png", 216,76, 80,20)
pusher = img_add("pusher.png", 304,76, 80,20)
fire_detect = img_add("fire_detect.png", 392,76, 80,20)
red_blank3= img_add("red_blank.png", 482,76, 80,20)
--row4
gen_1_off = img_add("gen_1_off.png", 40,103, 80,20)
inverter = img_add("inverter.png", 128,103, 80,20)
bat_hot = img_add("bat_hot.png", 216,103, 80,20)
flaps = img_add("flaps.png", 304,103, 80,20)
chip = img_add("chip.png", 392,103, 80,20)
caws_fail= img_add("caws_fail.png", 482,103, 80,20)
--row5
bat_off = img_add("bat_off.png", 40,130, 80,20)
fuel_press = img_add("fuel_press.png", 128,130, 80,20)
hydr = img_add("hydr.png", 216,130, 80,20)
ecs = img_add("ecs.png", 304,130, 80,20)
aoa_deice = img_add("aoa_de_ice.png", 392,130, 80,20)
nesntl_bus= img_add("n_esntl_bus.png", 482,130, 80,20)
--row6
l_fuel_low = img_add("l_fuel_low.png", 40,157, 80,20)
ap_diseng = img_add("ap_diseng.png", 128,157, 80,20)
deice_boots = img_add("de_ice_boots.png", 216,157, 80,20)
inert_sep = img_add("inert_sep.png", 304,157, 80,20)
static = img_add("static.png", 392,157, 80,20)
r_fuel_low= img_add("r_fuel_low.png", 482,157, 80,20)
--row7
battery = img_add("battery.png", 40,185, 80,20)
oil_qty_amber = img_add("oil_qty_amber.png", 128,185, 80,20)
wshld_heat = img_add("wshld_heat.png", 216,185, 80,20)
pitot1 = img_add("pitot_1.png", 304,185, 80,20)
pitot2 = img_add("pitot_2.png", 392,185, 80,20)
prop_deice= img_add("prop_de_ice.png", 482,185, 80,20)
--row8
l_fuel_pump = img_add("l_fuel_pump.png", 40,213, 80,20)
ap_trim_green = img_add("ap_trim_green.png", 128,213, 80,20)
pusher_ice_mode = img_add("pusher_ice_mode.png", 216,213, 80,20)
deice_boots_green = img_add("de_ice_boots_green.png", 304,213, 80,20)
pass_oxy = img_add("pass_oxy.png", 392,213, 80,20)
r_fuel_pump= img_add("r_fuel_pump.png", 482,213, 80,20)

visible(red_blank1, false)
visible(red_blank2, false)
visible(red_blank3, false)

function get_pass_door(myBool)
  visible(pass_door, myBool)
  b_pass_door = myBool
end

function get_car_door(myBool)
  visible(car_door, myBool)
  b_car_door = myBool
end

function get_cab_press(myBool)
  visible(cab_press, myBool)
  b_cab_press = myBool
end

function get_airgnd(myBool)
  visible(air_gnd, myBool)
  b_air_gnd = myBool
end

function get_prop_low_p(myBool)
  visible(prop_low_p, myBool)
  b_prop_low_p = myBool
end

function get_ap_trim_red(myBool)
  visible(ap_trim_red, myBool)
  b_ap_trim_red = myBool
end

function get_esntl_bus(myBool)
  visible(esntl_bus, myBool)
  b_esntl_bus = myBool
end

function get_av_bus(myBool)
  visible(av_bus, myBool)
  b_av_bus = myBool
end

function get_stab_trim(myBool)
  visible(stab_trim, myBool)
  b_stab_trim = myBool
end

function get_oil_qty(myBool)
  visible(oil_qty, myBool)
  b_oil_qty = myBool
end

function get_eng_fire(myBool)
  visible(eng_fire, myBool)
  b_eng_fire = myBool
end

function get_gen_2_off(myBool)
  visible(gen_2_off, myBool)
  b_gen_2_off = myBool
end

function get_bus_tie(myBool)
  visible(bus_tie, myBool)
  b_bus_tie = myBool
end

function get_pusher(myBool)
  visible(pusher, myBool)
  b_pusher = myBool
end

function get_fire_detect(myBool)
  visible(fire_detect, myBool)
  b_fire_detect = myBool
end

function get_gen1_off(myBool)
  visible(gen_1_off, myBool)
  b_gen_1_off = myBool
end

function get_inverter(myBool)
  visible(inverter, myBool)
  b_get_inverter = myBool
end

function get_bat_hot(myBool)
  visible(bat_hot, myBool)
  b_bat_hot = myBool
end

function get_flaps(myBool)
  visible(flaps, myBool)
  b_flaps = myBool
end

function get_chip(myBool)
  visible(chip, myBool)
  b_chip = myBool
end

function get_caws_fail(myBool)
  visible(caws_fail, myBool)
  b_caws_fail = myBool
end

function get_bat_off(myBool)
  visible(bat_off, myBool)
  b_bat_off = myBool
end

function get_fuel_press(myBool)
  visible(fuel_press, myBool)
  b_fuel_press = myBool
end

function get_hydr(myBool)
  visible(hydr, myBool)
  b_hydr = myBool
end

function get_ecs(myBool)
  visible(ecs, myBool)
  b_ecs = myBool
end

function get_aoa_deice(myBool)
  visible(aoa_deice, myBool)
  b_aoa_deice = myBool
end

function get_nesntl_bus(myBool)
  visible(nesntl_bus, myBool)
  b_nesntl_bus = myBool
end

function get_l_fuel_low(myBool)
  visible(l_fuel_low, myBool)
  b_l_fuel_low = myBool
end

function get_ap_diseng(myBool)
  visible(ap_diseng, myBool)
  b_ap_diseng = myBool
end

function get_deice_boots(myBool)
  visible(deice_boots, myBool)
  b_deice_boots = myBool
end

function get_inert_sep(myBool)
  visible(inert_sep, myBool)
  b_inert_sep = myBool
end

function get_static(myBool)
  visible(static, myBool)
  b_static = myBool
end

function get_r_fuel_low(myBool)
  visible(r_fuel_low, myBool)
  b_r_fuel_low = myBool
end

function get_battery(myBool)
  visible(battery, myBool)
  b_battery = myBool
end

function get_oil_qty_amber(myBool)
  visible(oil_qty_amber, myBool)
  b_oil_qty_amber = myBool
end

function get_wshld_heat(myBool)
  visible(wshld_heat, myBool)
  b_wshld_heat = myBool
end

function get_pitot1(myBool)
  visible(pitot1, myBool)
  b_pitot1 = myBool
end

function get_pitot2(myBool)
  visible(pitot2, myBool)
  b_pitot2 = myBool
end

function get_prop_deice(myBool)
  visible(prop_deice, myBool)
  b_prop_deice = myBool
end

function get_l_fuel_pump(myBool)
  visible(l_fuel_pump, myBool)
  b_l_fuel_pump = myBool
end

function get_ap_trim_green(myBool)
  visible(ap_trim_green, myBool)
  b_ap_trim_green = myBool
end

function get_pusher_ice_mode(myBool)
  visible(pusher_ice_mode, myBool)
  b_pusher_ics_mode = myBool
end

function get_deice_boots_green(myBool)
  visible(deice_boots_green, myBool)
  b_deice_boots_green = myBool
end

function get_pass_oxy(myBool)
  visible(pass_oxy, myBool)
  b_pass_oxy = myBool
end

function get_r_fuel_pump(myBool)
  visible(r_fuel_pump, myBool)
  b_r_fuel_pump = myBool
end

function lamp_test(myBool)
    if (myBool) then
      visible(red_blank1, myBool)
      visible(red_blank2, myBool)
      visible(red_blank3, myBool)
      visible(pass_door, myBool)
      visible(car_door, myBool)
      visible(cab_press, myBool)
      visible(air_gnd, myBool)
      visible(prop_low_p, myBool)
      visible(ap_trim_red, myBool)
      visible(esntl_bus, myBool)
      visible(av_bus, myBool)
      visible(stab_trim, myBool)
      visible(oil_qty, myBool)
      visible(eng_fire, myBool)
      visible(gen_2_off, myBool)
      visible(bus_tie, myBool)
      visible(pusher, myBool)
      visible(fire_detect, myBool)
      visible(gen_1_off, myBool)
      visible(inverter, myBool)
      visible(bat_hot, myBool)
      visible(flaps, myBool)
      visible(chip, myBool)
      visible(caws_fail, myBool)
      visible(bat_off, myBool)
      visible(fuel_press, myBool)
      visible(hydr, myBool)
      visible(ecs, myBool)
      visible(aoa_deice, myBool)
      visible(nesntl_bus, myBool)
      visible(l_fuel_low, myBool)
      visible(ap_diseng, myBool)
      visible(deice_boots, myBool)
      visible(inert_sep, myBool)
      visible(static, myBool)
      visible(r_fuel_low, myBool)
      visible(battery, myBool)
      visible(oil_qty_amber, myBool)
      visible(wshld_heat, myBool)
      visible(pitot1, myBool)
      visible(pitot2, myBool)
      visible(prop_deice, myBool)
      visible(l_fuel_pump, myBool)
      visible(ap_trim_green, myBool)
      visible(pusher_ice_mode, myBool)
      visible(deice_boots_green, myBool)
      visible(pass_oxy, myBool)
      visible(r_fuel_pump, myBool)
    else
      visible(red_blank1, b_red_blank1)
      visible(red_blank2, b_red_blank2)
      visible(red_blank3, b_red_blank3)
      visible(pass_door, b_pass_door)
      visible(car_door, b_car_door)
      visible(cab_press, b_cab_press)
      visible(air_gnd, b_air_gnd)
      visible(prop_low_p, b_prop_low_p)
      visible(ap_trim_red, b_ap_trim_red)
      visible(esntl_bus, b_esntl_bus)
      visible(av_bus, b_av_bus)
      visible(stab_trim, b_stab_trim)
      visible(oil_qty, b_oil_qty)
      visible(eng_fire, b_eng_fire)
      visible(gen_2_off, b_gen_2_off)
      visible(bus_tie, b_bus_tie)
      visible(pusher, b_pusher)
      visible(fire_detect, b_fire_detect)
      visible(gen_1_off, b_gen_1_off)
      visible(inverter, b_inverter)
      visible(bat_hot, b_bat_hot)
      visible(flaps, b_flaps)
      visible(chip, b_chip)
      visible(caws_fail, b_caws_fail)
      visible(bat_off, b_bat_off)
      visible(fuel_press, b_fuel_press)
      visible(hydr, b_hydr)
      visible(ecs, b_ecs)
      visible(aoa_deice, b_aoa_deice)
      visible(nesntl_bus, b_nesntl_bus)
      visible(l_fuel_low, b_l_fuel_low)
      visible(ap_diseng, b_ap_diseng)
      visible(deice_boots, b_deice_boots)
      visible(inert_sep, b_inert_sep)
      visible(static, b_static)
      visible(r_fuel_low, b_r_fuel_low)
      visible(battery, b_battery)
      visible(oil_qty_amber, b_oil_qty_amber)
      visible(wshld_heat, b_wshld_heat)
      visible(pitot1, b_pitot1)
      visible(pitot2, b_pitot2)
      visible(prop_deice, b_prop_deice)
      visible(l_fuel_pump, b_l_fuel_pump)
      visible(ap_trim_green, b_ap_trim_green)
      visible(pusher_ice_mode, b_pusher_ice_mode)
      visible(deice_boots_green, b_deice_boots_green)
      visible(pass_oxy, b_pass_oxy)
      visible(r_fuel_pump, b_r_fuel_pump)
    end
  
end

--subscriptions
--row 1
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_PASS_DOOR", "Bool", get_pass_door)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_CAR_DOOR", "Bool", get_car_door)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_CAB_PRESS", "Bool", get_cab_press)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_AIRGND", "Bool", get_airgnd)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_PROP_LOW_P", "Bool", get_prop_low_p)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_AP_TRIM_RED", "Bool", get_ap_trim_red)
--row 2
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_ESNTL_BUS", "Bool", get_esntl_bus)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_AV_BUS", "Bool", get_av_bus)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_STAB_TRIM", "Bool", get_stab_trim)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_OIL_QTY", "Bool", get_oil_qty)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_ENG_FIRE", "Bool", get_eng_fire)
--row 3
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_GEN2_OFF", "Bool", get_gen_2_off)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_BUS_TIE", "Bool", get_bus_tie)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_PUSHER", "Bool", get_pusher)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_FIRE_DETECT", "Bool", get_fire_detect)
--row 4
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_CAWS_GEN1_OFF", "Bool", get_gen1_off)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_INVERTER", "Bool", get_inverter)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_BAT_HOT", "Bool", get_bat_hot)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_FLAPS", "Bool", get_flaps)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_CHIP", "Bool", get_chip)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_CAWS_FAIL", "Bool", get_caws_fail)
--row 5
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_BAT_OFF", "Bool", get_bat_off)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_FUEL_PRESS", "Bool", get_fuel_press)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_HYDR", "Bool", get_hydr)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_ECS", "Bool", get_ecs)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_AOA_DEICE", "Bool", get_aoa_deice)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_NESNTL_BUS", "Bool", get_nesntl_bus)
--row 6
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_L_FUEL_LOW", "Bool", get_l_fuel_low)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_AP_DISENG", "Bool", get_ap_diseng)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_DEICE_BOOTS", "Bool", get_deice_boots)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_INERT_SEP", "Bool", get_inert_sep)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_STATIC", "Bool", get_static)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_R_FUEL_LOW", "Bool", get_r_fuel_low)
--row 7
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_BATTERY", "Bool", get_battery)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_OIL_QTY_AMBER", "Bool", get_oil_qty_amber)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_WSHLD_HEAT", "Bool", get_wshld_heat)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_PITOT1", "Bool", get_pitot1)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_PITOT2", "Bool", get_pitot2)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_PROP_DEICE", "Bool", get_prop_deice)
--row 8
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_L_FUEL_PUMP", "Bool", get_l_fuel_pump)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_AP_TRIM_GREEN", "Bool", get_ap_trim_green)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_PUSHER_ICE_MODE", "Bool", get_pusher_ice_mode)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_DEICE_BOOTS_GREEN", "Bool", get_deice_boots_green)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_PASS_OXY", "Bool", get_pass_oxy)
fs2020_variable_subscribe("L:SAFETY_CAWS_Light_R_FUEL_PUMP", "Bool", get_r_fuel_pump)

fs2020_variable_subscribe("L:SAFETY_Push_TestLamp", "Bool", lamp_test)
