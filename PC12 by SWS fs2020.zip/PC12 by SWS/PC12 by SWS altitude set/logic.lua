img_add_fullscreen("pc12 altitude set.png")
txt_select = txt_add("0000", "size:30px; color: #a34100; halign: right;", 50, 115, 120, 80)
txt_comma = txt_add(",", "size:30px; color: #a34100; halign: left;", 115, 118, 10, 80)
txt_vs = txt_add("VS", "size:13px; color: #a34100; halign: left;", 70, 100, 50, 50)
txt_arm = txt_add("ARM", "size:13px; color: #a34100; halign: left;", 70, 150, 50, 50)
txt_capt = txt_add("CAPT", "size:13px; color: #a34100; halign: left;", 95, 150, 50, 50)
txt_feet = txt_add("FT", "size:13px; color: #a34100; halign: right;", 120, 150, 50, 50)
txt_up = txt_add("^", "size:20px; color: #a34100; halign: left;", 80, 115, 10, 10)
txt_dn = txt_add("^", "size:20px; color: #a34100; halign: left;", 80, 135, 10, 10)
txt_alert = txt_add("ALERT", "size:15px; color: #a34100; halign: left;", 130, 100, 100, 50)
rotate(txt_dn, 180)
visible(txt_up, false)
visible(txt_dn, false)
visible(txt_arm, false)
visible(txt_vs, false)
visible(txt_capt, false)

local alt_sel = 0
local vs_sel = 0
local b_rate = false
local b_vs = false
local ind_alt = 0
local b_arm = false
local blink_cnt = 0
local b_blink_ON = true
local b_arlert = false
local b_startup = true
local startup_count = 2
local b_showVS = false
local VStimer = 0
local b_capt = false
--local b_resetVS = false

--functions
function update_alt_text()
    visible(txt_up, false)
    visible(txt_dn, false)
    local txt
    
    if (b_rate or b_showVS) then--rate select
        local abs = math.abs(vs_sel)
        txt = math.floor(abs)-- .. "00"
        if (vs_sel < 0) then
            visible(txt_dn, true)
        else
            visible(txt_up, true)
        end
        
    else--altitude select
        txt = math.floor(alt_sel)
    end
      
    txt = tostring(txt)
    txt_set(txt_select, txt)
    
    if (string.len(txt) <= 3) then
        visible(txt_comma, false)
    else
        visible(txt_comma, true)
    end
    
    --doAlert(ind_alt)
end

function get_sel_alt(myAlt)
    alt_sel = myAlt
    
    --no tenths
    alt_sel = math.floor(alt_sel / 100) * 100
    
    update_alt_text()
end

--dial functions
function outter_knob(direction)
  -- Direction will have the value
  --  1: When the dial is being turned clockwise
  -- -1: When the dial is being turned anti-clockwise
  
 blink_cnt = 0
 
 if (b_rate and not b_arm) then fs2020_event("H:AUTOPILOT_KAS297B_Push_AltitudeSelect_1") end
 
 if (direction > 0)then
       fs2020_event("H:SWS_KAS297_Outer_Knob_CW")
       if (b_rate) then
           vs_sel = vs_sel + 1000
           if (vs_sel > 3000) then vs_sel = 3000 end
       else
           alt_sel = alt_sel + 1000
           if (alt_sel > 50000) then alt_sel = 50000 end
       end
       
 else
       fs2020_event("H:SWS_KAS297_Outer_Knob_CCW")
       if (b_rate) then
           vs_sel = vs_sel - 1000
           if (vs_sel < -3000) then vs_sel = -3000 end
       else
           alt_sel = alt_sel - 1000
           if (alt_sel < 0) then alt_sel = 0 end
       end
 end
 
end

function inner_knob(direction)
  -- Direction will have the value
  --  1: When the dial is being turned clockwise
  -- -1: When the dial is being turned anti-clockwise
  
  blink_cnt = 0
  
  if (b_rate and not b_arm) then fs2020_event("H:AUTOPILOT_KAS297B_Push_AltitudeSelect_1") end
  
 if (direction > 0)then
       fs2020_event("H:SWS_KAS297_Inner_Knob_CW")
       if (b_rate) then
           vs_sel = vs_sel + 100
           if (vs_sel > 3000) then vs_sel = 3000 end
       else
           alt_sel = alt_sel + 100
           if (alt_sel > 50000) then alt_sel = 50000 end
       end
 else
       fs2020_event("H:SWS_KAS297_Inner_Knob_CCW")
       if (b_rate) then
           vs_sel = vs_sel - 100
           if (vs_sel < -3000) then vs_sel = -3000 end
       else
           alt_sel = alt_sel - 100
           if (alt_sel < 0) then alt_sel = 0 end
       end
 end
end

--buttons
function vs_button_pressed()

    fs2020_event("H:AUTOPILOT_KAS297B_Push_VerticalSpeed_1")
    
    if (not b_vs) then
        b_showVS = true
        VStimer = 5
    end
    
end

function arm_button_pressed()
    if (not b_rate) then
        --fs
        fs2020_event("H:AUTOPILOT_KAS297B_Push_AltitudeSelect_1")
    end
end

function dial_button_pressed()
    
    b_rate = not b_rate
    visible(txt_select, true)
    blink_cnt = 0
    b_blink = true
    
    fs2020_variable_write("L:AUTOPILOT_KAS297B_MODE", "Bool", b_rate)
    
    if (b_rate) then
        --vs_sel = 0
        txt_set(txt_feet, "FT/min")
        
        --reset VS sel
        local alt = math.floor(ind_alt)
        local diff = math.abs(alt - alt_sel)
        if (diff > 100) then--not at selected altitude
            if (alt_sel > alt and vs_sel < 0) then--alt select is higher but vs select is descending
               resetVS()
            elseif (alt_sel < alt and vs_sel > 0) then--alt select is lower but vs select is climbing
               resetVS()
            end
        end
        
    else
        txt_set(txt_feet, "FT")
    end
    
    update_alt_text()
    
end

function doAlert(myFloat)
    if (myFloat == 1) then
        visible(txt_alert, true)
    else
        visible(txt_alert, false)
    end
    
end

function timer_callback()
    visible(txt_select, true)
    if (b_rate) then
        blink_cnt = blink_cnt + 1
        if (blink_cnt >= 10) then
            blink_cnt = 10
            b_blink_ON = not b_blink_ON
        else
            b_blink_ON = true
            visible(txt_select, true)
        end
        visible(txt_select, b_blink_ON)
    end
    
    --update alt/vs text
    update_alt_text()
    
    --sync alt_sel and sim alt_sel on startup
    if (b_startup)then
        if (startup_count > 0)then
            startup_count = startup_count - 1
            if (startup_count == 1)then arm_button_pressed() end
        elseif (startup_count == 0)then
            arm_button_pressed()
            b_startup = false
        end
    end
    
    --show vs for a short time
    if (b_showVS) then
        VStimer = VStimer - 1
        if (VStimer == 0)then
            b_showVS = false
        end
    end
    
end

function get_ARM(myFloat)
    if (myFloat == 1) then
        b_arm = true
    else
        b_arm = false
    end
    
    visible(txt_arm, b_arm)
end

function ap_mode(myBool)
    b_rate = myBool
    update_alt_text()
end

function get_alt_sel(feet)
   alt_sel = feet
   update_alt_text()
end

function get_vs_sel(feet)
    vs_sel = feet
    update_alt_text()
end

function get_vs_hold(myBool)
    visible(txt_vs, myBool)
    b_vs = myBool
end
  
function alt_capture(myBool)
    b_capt = myBool
    visible(txt_capt, myBool)
    if (b_capt) then visible(txt_arm, false) end
end

function resetVS()
    diff = 0
    --roll vs select down to zero
    if (vs_sel > 0) then
        diff = vs_sel / 100
        for i = 1, diff, 1 do
            fs2020_event("H:SWS_KAS297_Inner_Knob_CCW")
        end
    end
    
    --roll vs select up to zero
    if (vs_sel < 0) then
        diff = vs_sel * -1
        diff = diff / 100
        for i = 1, diff, 1 do
            fs2020_event("H:SWS_KAS297_Inner_Knob_CW")
        end
    end
end

function get_alt(feet)
    ind_alt = feet
end

--variable subscriptions
--fs
fs2020_variable_subscribe("AUTOPILOT VERTICAL HOLD", "Bool", get_vs_hold)
fs2020_variable_subscribe("L:SWS_KAS297B_AltitudeArm", "float", get_ARM)
fs2020_variable_subscribe("L:AUTOPILOT_AltitudeAlert_Warning", "float", doAlert)
fs2020_variable_subscribe("L:SWS_KAS297B_AltitudeCapture", "boolean", alt_capture)
fs2020_variable_subscribe("AUTOPILOT ALTITUDE LOCK VAR", "feet", get_alt_sel)
fs2020_variable_subscribe("AUTOPILOT VERTICAL HOLD VAR", "FEET PER MINUTE", get_vs_sel)
fs2020_variable_subscribe("AUTOPILOT_KAS297B_MODE", "Bool", ap_mode)
fs2020_variable_subscribe("INDICATED ALTITUDE", "Feet", get_alt)

--add dials
dial_add("outter_knob.png",180,100,60,60, outter_knob)
dial_add("inner_knob.png",195,115,30,30,5, inner_knob)

--add buttons
button_add(nil, nil, 20, 100, 40, 40, vs_button_pressed)
button_add(nil, nil, 20, 135, 40, 40, arm_button_pressed)
button_add(nil, nil, 205, 115, 15, 15, dial_button_pressed)

timer_start(0, 500, timer_callback)--loop timer for blink



--used to sync with PC12 altitude select
--dial_button_pressed()
--dial_button_pressed()
