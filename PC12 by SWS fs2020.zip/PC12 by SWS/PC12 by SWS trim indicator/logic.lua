img_add_fullscreen("trim_backdrop.png")
img_aileron = img_add("trim_aileron.png",28,33,55,55)
img_rudder = img_add("trim_rudder.png",105,37,50,50)
img_elevator = img_add("trim_elevator.png",175,32,50,50)
img_autoroll = img_add("auto_trimlight.png",58,29,11,11)
img_autoyaw = img_add("auto_trimlight.png", 108,29,10,10)
img_autopitch = img_add("auto_trimlight.png", 190,29,10,10)

function PT_trim(aileron,rudder,elevator)
    rotate(img_aileron, aileron*60)
    rotate(img_rudder, rudder*60)
    rotate(img_elevator, elevator*40)
end

function PT_trim_FSX(elevator, aileron, rudder)

    elevator = elevator / 100
    aileron = aileron / 100
    rudder = rudder / 100--100
    
    print(rudder)
    
    PT_trim(aileron, rudder, elevator)

end

function autoroll(myBool)
    visible(img_autoroll, myBool)
end

function autoyaw(myBool)
    visible(img_autoyaw, myBool)
end

function autopitch(myBool)
    visible(img_autopitch, myBool)
end

xpl_dataref_subscribe("sim/cockpit2/controls/aileron_trim", "FLOAT",
                      "sim/cockpit2/controls/rudder_trim", "FLOAT",
                      "sim/cockpit2/controls/elevator_trim", "FLOAT", PT_trim)
fsx_variable_subscribe("ELEVATOR TRIM PCT", "Percent",
                       "AILERON TRIM PCT", "Percent",
                       "RUDDER TRIM PCT", "Percent", PT_trim_FSX)
fs2020_variable_subscribe("ELEVATOR TRIM PCT", "Percent",
                          "AILERON TRIM PCT", "Percent",
                          "RUDDER TRIM PCT", "Percent", PT_trim_FSX)    
                          
fs2020_variable_subscribe("L:LIGHT_Autotrim_Roll", "Bool", autoroll)
fs2020_variable_subscribe("L:LIGHT_Autotrim_Yaw", "Bool", autoyaw)
fs2020_variable_subscribe("L:LIGHT_Autotrim_Pitch", "Bool", autopitch)
                   